
counter = 0
modetitle = 0;
modegame = 1;
modeover = 2;
mode = modetitle;
bx=24
by=18
sx=0
sy=0
scene = 0;
ff = true;
MapReadF = false;
setup = function(){
    // setupbg( 5,10, 11,10)//0海、1草
    // setupbg(13,10, 10,10)//2森、3茂み
    // setupbg(12,10, 11,11)//4砂、5山
    // setupbg(13,11,  9,10)//6岩山、7氷
}
loop = function(){
    // if(ff){
        // setupbg( 5,10, 11,10)//0海、1草
        // setupbg(13,10, 10,10)//2森、3茂み
        // setupbg(12,10, 11,11)//4砂、5山
        // setupbg(13,11,  9,10)//6岩山、7氷
    //     ff =false;
    // }
    game()
    // if (mode == modetitle)title()
    // else if(mode == modegame)game()
    // else if(mode == modeover)over()
    // counter++
}
title = function(){

    // color(8);
    // fillrect(0,0,128,128);
    // color(1);
    // text("「警備員に捕まっちゃう？」", 17,42);
    // text("矢印キーで逃げよう！",20, 85);
    // if( btn(2) == true ){
    //     mode = modegame;
    // }
}
over = function(){
    color(2)
    fillrect(0,0,128,128)
    color(7)
    text("ゲームオーバー",32, 52)
    if( btn(2) == true )mode = modetitle
}
game = function(){
    if( btn(0) == true )bx--
    if( btn(1) == true )bx++
    if( btn(2) == true )by--
    if( btn(3) == true )by++

    if(bx<0)bx = 256
    if(by<0)by = 256

    sx = (bx + 8)%256//キャラの位置を割り出す//画面左上の内部処理と一致させている
    sy = (by + 7)%256

    if(scene == 0){//シーン0 街
    
        if(sx < 32 || sx > 63 || sy > 40 || sy < 1){//街を出たら
            scene = 1;//シーンを外に
            if(MapReadF == false){
                //マップを差し替える
                mapno(0);//転生先のデータを読み込む
                bx = 36//転生先
                by = 28
                MapReadF = true;
                }
                bg(bx,by,128,128);
        }else{//街の中の時
            bg(bx,by,128,128);
        }
    }else  if(scene == 1){//シーン1 外 
        MapReadF = false
        scene = 0;
        bg(bx,by,128,128);

    }
    // if(MapReadF == false){
    //     //マップを差し替える
    //     // readmap("/init/town.png");//転生先のデータを読み込む
    //     mapno(1);
    //     bx = 108//転生先
    //     by = 127
    //     MapReadF = true;
    //     }
    // bg(bx,by,128,128);

    spr(64,56,8,8,0,0)
}